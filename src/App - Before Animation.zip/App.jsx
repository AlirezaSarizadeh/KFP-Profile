import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Home from './pages/Home/Home'
import DentistPage from './pages/DentistPage/DentistPage'
import Login from './pages/Login/Login'
import Register from './pages/Register/Register'
import NoPage from './pages/404/404'
import { BrowserRouter, redirect, Route, Routes } from 'react-router-dom'
import Profile from './pages/Profile/Profile'
import Videos from './components/videos/Videos'
import Photos from './components/photos/Photos'
import Documents from './components/documents/Documents'
import Photo from './pages/Photo/Photo'
import Video from './pages/Video/Video'
import DocumentPage from './pages/Document/DocumentPage'
import Search from './pages/Search/Search'

function App() {

  return (
    // <>
    //   {/* <Home /> */}
    //   {/* <DentistPage /> */}
    //   {/* <Login /> */}
    //   <Register />
    // </>

    <BrowserRouter>
      <Routes>
        <Route path="/">
          <Route index element={<Home />} />

          {/* Dentists Routes  */}
          <Route path="/dentists" element={<DentistPage />} >
            <Route path="/dentists/videos" element={<Videos />} />
            <Route path="/dentists/documents" element={<Documents />} />
            <Route path="/dentists/photos" element={<Photos />} />
          </Route>
          <Route path="/dentists/photos/:id" element={<Photo />} />
          <Route path="/dentists/videos/:id" element={<Video />} />
          <Route path="/dentists/documents/:id" element={<DocumentPage />} />

          <Route path="/search/:id" element={<Search />} />

          <Route path="/profile" element={<Profile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>

  )
}

export default App
